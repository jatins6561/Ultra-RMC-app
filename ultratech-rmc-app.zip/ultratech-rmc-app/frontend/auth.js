// ------------------------------
// Shared Auth Helper for Frontend
// ------------------------------

// Dynamically detect backend URL (works for Live Server + localhost)
const API_BASE =
  (location.hostname === '127.0.0.1' || location.hostname === 'localhost')
    ? `http://${location.hostname}:4000`
    : ''; // If hosted later, it’ll auto-use same domain

// Authentication helper (token + user info stored in localStorage)
const AUTH = {
  get token() {
    return localStorage.getItem('token') || '';
  },
  set token(v) {
    localStorage.setItem('token', v);
  },

  get user() {
    try {
      return JSON.parse(localStorage.getItem('user') || 'null');
    } catch {
      return null;
    }
  },
  set user(u) {
    localStorage.setItem('user', JSON.stringify(u));
  },

  clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },
};

// Redirect to login if token missing
function requireAuth() {
  if (!AUTH.token) {
    // Save the current page so user comes back here after login
    sessionStorage.setItem('redirectAfterLogin', location.pathname);
    location.href = 'login.html';
  }
}

// Logout helper
function logout() {
  AUTH.clear();
  location.href = 'login.html';
}

// ------------------------------
// Helper: Authorized fetch wrapper
// ------------------------------
async function apiFetch(url, options = {}) {
  const headers = options.headers || {};
  if (AUTH.token) headers['Authorization'] = `Bearer ${AUTH.token}`;
  headers['Content-Type'] = 'application/json';
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json();
}

console.log('✅ Auth helpers loaded, API_BASE =', API_BASE);
